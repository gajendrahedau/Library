package com.cg.library.services;
public interface LibraryService {
}
