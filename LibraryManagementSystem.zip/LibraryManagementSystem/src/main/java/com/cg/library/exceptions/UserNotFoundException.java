package com.cg.library.exceptions;

public class UserNotFoundException {

}
