package com.cg.library.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.library.daoservices.BookDAO;
import com.cg.library.daoservices.TransactionDAO;
import com.cg.library.daoservices.UserDAO;

@Component("libraryService")
public class LibraryServiceImpl implements LibraryService{
	@Autowired
	private BookDAO bookDAO;
	@Autowired
	private TransactionDAO transactionDAO;
	@Autowired
	private UserDAO userDAO;
	
}
